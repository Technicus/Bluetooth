Android Bluetooth  Discovery sample , native code implementation using BlueZ and C
==================================================================================

(C)2010 Radu Motisan , All rights reserved.

Web: www.pocketmagic.net
Email: radu.motisan@gmail.com

If you want to include any part of this code into your application, you will need my written permission.

