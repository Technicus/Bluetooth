package net.pocketmagic.perseus;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;

public class PerseusAndroid extends Activity implements OnClickListener, OnItemClickListener {
	//-- ROBOT --//
	final static String			ROBO_BTADDR				= "00:1D:43:00:E4:78";
	//-- debugging --//	
	String 						LOG_TAG 				= "PerseusAndroid";
	//-- GUI --//
	final static String			m_szAppTitle			= "PerseusAndroid";
	TabHost						m_tabHost;
	ListView					m_lvSearch;	
	ProgressDialog				m_progDlg;
	
	//-- Bluetooth functionality --//
	BTNative					m_BT;
	int							m_nDiscoverResult 		= -1;
	int							m_nRoboDev				= -1;
	final Handler 				m_Handler 				= new Handler();	//used for discovery thread, etc
	
	
	
	public static final int 	idMenuTab1Search	= Menu.FIRST +   1,
								idLVFirstItem		= Menu.FIRST + 100;	

	private View createTabContent1()
	{
		final Context context = PerseusAndroid.this;
		// Tab container
    	LinearLayout panel = new LinearLayout(context);
  		panel.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
  		panel.setOrientation(LinearLayout.VERTICAL);
  		
  		LinearLayout panelH = new LinearLayout(context);
     	panelH.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
  		panelH.setOrientation(LinearLayout.HORIZONTAL);
  		panelH.setGravity(Gravity.LEFT);
  		panelH.setGravity(Gravity.CENTER_VERTICAL);

  		Button but = new Button(this);
  		but.setText("Search BT Devices");
  		but.setId(idMenuTab1Search);
  		but.setOnClickListener(this);
  		but.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
     	panelH.addView(but);
     	
     	panel.addView(panelH);


		m_lvSearch = new ListView( this );
	 	// clear previous results in the LV
		m_lvSearch.setAdapter(null);      
		m_lvSearch.setOnItemClickListener((OnItemClickListener) this);
		
	    panel.addView(m_lvSearch);
	    TextView lbBottom = new TextView(context);
    	lbBottom.setText("Press the button to discover Bluetooth devices");
    	lbBottom.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
     	panel.addView(lbBottom);

	    
	    return panel;
	}
	
	private View createTabContent2()
	{
		final Context context = PerseusAndroid.this;
		// Tab container
    	LinearLayout panel = new LinearLayout(context);
  		panel.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
  		panel.setOrientation(LinearLayout.VERTICAL);
  		
  		return panel;
	}
	
	/** This function creates the Main interface: the TAB host **/
	private View createMainTABHost() {
		// construct the TAB Host
    	TabHost tabHost = new TabHost(this);
    	tabHost.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
 
        // the tabhost needs a tabwidget, that is a container for the visible tabs
        TabWidget tabWidget = new TabWidget(this);
        tabWidget.setId(android.R.id.tabs);
        tabHost.addView(tabWidget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT)); 
 
        // the tabhost needs a frame layout for the views associated with each visible tab
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setId(android.R.id.tabcontent);
        frameLayout.setPadding(0, 65, 0, 0);
        tabHost.addView(frameLayout, new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)); 
 
        // setup must be called if you are not initialising the tabhost from XML
        tabHost.setup(); 
 
        // create the tabs
        TabSpec ts;
        ImageView iv;
        
        ts = tabHost.newTabSpec("TAB_TAG_1");
        ts.setIndicator("Search");
        ts.setContent(new TabHost.TabContentFactory()
        {
            public View createTabContent(String tag)
            {
            	return createTabContent1();
             } //TAB 1 done
        });
        tabHost.addTab(ts);
        // -- set the image for this tab
        iv = (ImageView)tabHost.getTabWidget().getChildAt(0).findViewById(android.R.id.icon);
        if (iv != null) iv.setImageDrawable(getResources().getDrawable(R.drawable.bt));

 
        ts = tabHost.newTabSpec("TAB_TAG_2");
        ts.setIndicator("Control");
        ts.setContent(new TabHost.TabContentFactory(){
             public View createTabContent(String tag)
             {
            	 return createTabContent2();
             }
        });
        tabHost.addTab(ts);
        // -- set the image for this tab
        iv = (ImageView)tabHost.getTabWidget().getChildAt(1).findViewById(android.R.id.icon);
        if (iv != null) iv.setImageDrawable(getResources().getDrawable(R.drawable.perseus));
        
        return tabHost;
	}
    
	 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_BT = new BTNative();
        
        // disable the titlebar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // create the interface
        m_tabHost = (TabHost)createMainTABHost();
    	
        setContentView(m_tabHost);
    }


	@Override
	public void onClick(View v) {
		int cmdId = v.getId();
		if (cmdId == idMenuTab1Search)
		{
			startDiscoverBluetoothDevices();
		}
	}
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		if (m_tabHost.getCurrentTab() == 0) //we are on SEARCH page (0)
		{
		}
		
	}
	
	/** Bluetooth Functions **/
	final Runnable mUpdateResultsDiscover = new Runnable() {
        public void run() {
        	doneDiscoverBluetoothDevices();
        }
    };
    protected void startDiscoverBluetoothDevices() {
    	// Show Please wait dialog
    	m_progDlg = ProgressDialog.show(this,
    			m_szAppTitle, "Scanning, please wait",
    			true);
    	
    	// Fire off a thread to do some work that we shouldn't do directly in the UI thread
	    Thread t = new Thread() {
	    	public void run() 
	    	{
	    		// blocking operation
            		m_nDiscoverResult = m_BT.DiscoverBluetoothDevices();
            	//show results
	        	m_Handler.post(mUpdateResultsDiscover);
	    	}
	    };
	    t.start();
    }
    
    private void doneDiscoverBluetoothDevices() 
    {
    	m_progDlg.dismiss();
    	if (m_nDiscoverResult == -1)
    		Toast.makeText(getBaseContext(), "Bluetooth ERROR (is bluetooth on?)", Toast.LENGTH_LONG).show();
    	else if (m_nDiscoverResult == 0)
    		Toast.makeText(getBaseContext(), "No Bluetooth devices found", Toast.LENGTH_LONG).show();
    	else {
    		m_nRoboDev = -1;
    		// populate
			ArrayList<Device> m_Devices = new ArrayList<Device>();
				Device device;
		        for (int i=0;i<m_BT.BTCount;i++) {
		        	if (m_BT.BTDevs[i].m_szAddress.compareTo(PerseusAndroid.ROBO_BTADDR) == 0) {
		        		m_BT.BTDevs[i].m_nBTDEVType = 1;
		        		m_nRoboDev = i;
		        	}
		        	else 
		        		m_BT.BTDevs[i].m_nBTDEVType = 0;
		        	device = new Device(m_BT.BTDevs[i].m_szName, 
		        			m_BT.BTDevs[i].m_szAddress, 
		        			m_BT.BTDevs[i].m_nBTDEVType,
		        			0, 
		        			idLVFirstItem+i);
		        	m_Devices.add(device);
		        }
		    CustomAdapter lvAdapter =  new CustomAdapter(this, m_Devices);
		    if (lvAdapter!=null) m_lvSearch.setAdapter(lvAdapter);
		    if (m_nRoboDev >= 0)
		    	Toast.makeText(getBaseContext(), "ROBO found as "+m_BT.BTDevs[m_nRoboDev].m_szAddress, 
		    			Toast.LENGTH_LONG).show();
    	}
	    //Log.d(LOG_TAG, "Discovery complete. Results: " + m_BT.BTCount);
    }



    
}

